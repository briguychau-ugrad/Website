#include <stdio.h>
#include <stdlib.h>
#include "registers.h"
#include "state.h"

/*
 Sequential Y86 simulator
 Author: Brian Chau (c) 2013
*/

#define BUILD_VERSION "20130519-1.0.0001"

char* statcode[5] = {(char*)"X", (char*)"AOK", (char*)"HLT", (char*)"ADR", (char*)"INS"};
unsigned int codesize;
unsigned char* L1;
Registers registers;
unsigned int PC;
bool CC[3];

void fetch(State* f) {
	if (f == NULL) return;
	if (PC >= codesize) {
		f->status = 3;
		return;
	}
	
	unsigned char instr[6];
	
	for (int i = 0; i <= 6; i++) {
		instr[i] = L1[PC + i];
	}
	
	unsigned char op = instr[0]>>4;
	
	f->icode = op;
	f->ifun = instr[0]&0x0f;
	
	switch (op) {
		case 0x0:
			f->status = 2U;
			f->valP = PC + 1U;
			break;
		case 0x1:
		case 0x9:
			f->valP = PC + 1U;
			break;
		case 0x2:
		case 0x6:
			f->rA = instr[1]>>4;
			f->rB = instr[1]&0x0f;
			f->valP = PC + 2U;
			break;
		case 0x3:
			f->rB = instr[1]&0x0f;
			f->valC = instr[2] + (instr[3]<<8) + (instr[4]<<16) + (instr[5]<<24);
			f->valP = PC + 6U;
			break;
		case 0x4:
		case 0x5:
			f->rA = instr[1]>>4;
			f->rB = instr[1]&0x0f;
			f->valC = instr[2] + (instr[3]<<8) + (instr[4]<<16) + (instr[5]<<24);
			f->valP = PC + 6U;
			break;
		case 0x7:
		case 0x8:
			f->valC = instr[1] + (instr[2]<<8) + (instr[3]<<16) + (instr[4]<<24);
			f->valP = PC + 5U;
			break;
		case 0xa:
		case 0xb:
			f->rA = instr[1]>>4;
			f->valP = PC + 2U;
			break;
		// UBC ONLY
		case 0xe:
			f->rB = instr[1]&0x0f;
			f->valC = instr[2] + (instr[3]<<8) + (instr[4]<<16) + (instr[5]<<24);
			f->valP = PC + 6U;
			break;
		// END UBC ONLY
		default:
			f->status = 4;
			break;
	}
	return;
}

void decode(State* d) {
	if (d == NULL) return;
	switch (d->icode) {
		case 0x2:
			d->dstE = d->rB;
			d->srcA = d->rA;
			break;
		case 0x3:
			d->dstE = d->rB;
			break;
		case 0x4:
			d->srcA = d->rA;
			d->srcB = d->rB;
			break;
		case 0x5:
			d->dstM = d->rA;
			d->srcB = d->rB;
			break;
		case 0x6:
			d->dstE = d->rB;
			d->srcA = d->rA;
			d->srcB = d->rB;
			break;
		case 0x8:
			d->dstE = 0x4;
			d->srcB = 0x4;
			break;
		case 0x9:
			d->dstE = 0x4;
			d->srcA = 0x4;
			d->srcB = 0x4;
			break;
		case 0xa:
			d->dstE = 0x4;
			d->srcA = d->rA;
			d->srcB = 0x4;
			break;
		case 0xb:
			d->dstE = 0x4;
			d->dstM = d->rA;
			d->srcA = 0x4;
			d->srcB = 0x4;
			break;
		case 0xe:
			d->srcB = d->rB;
			break;
	}
	d->valA = (unsigned int)registers.getRegister(d->srcA);
	d->valB = (unsigned int)registers.getRegister(d->srcB);
}

void alu(State* a) {
	long long aluA = (long long)a->valA;
	long long aluB = (long long)a->valB;
	long long result;
	switch (a->ifun) {
		case 0x0:
			result = aluB + aluA;
			break;
		case 0x1:
			result = aluB - aluA;
			break;
		case 0x2:
			result = aluB & aluA;
			break;
		case 0x3:
			result = aluB ^ aluA;
			break;
		// UBC ONLY
		case 0x4:
			result = aluB * aluA;
			break;
		case 0x5:
			result = aluB / aluA;
			break;
		case 0x6:
			result = aluB % aluA;
			break;
		// END UBC ONLY
		default:
			a->status = 4;
			return;
	}
	a->valE = (unsigned int)(result % 0x100000000ll);
	CC[0] = ((int)a->valE == 0);
	CC[1] = ((int)a->valE < 0);
	CC[2] = ((unsigned long long)a->valE != (unsigned long long)result);
}

void execute(State* e) {
	if (e == NULL) return;
	switch (e->icode) {
		case 0x2:
			e->valE = e->valA;
			break;
		case 0x3:
			e->valE = e->valC;
			break;
		case 0x4:
		case 0x5:
			e->valE = e->valB + e->valC;
			break;
		case 0x6:
			alu(e);
			if (e->status == 4) return;
			break;
		case 0x8:
			e->Bch = true;
		case 0xa:
			e->valE = e->valB - 0x4;
			break;
		case 0x9:
			e->Bch = true;
		case 0xb:
			e->valE = e->valB + 0x4;
			break;
		case 0xe:
			e->Bch = true;
			e->valE = e->valB + e->valC;
			break;
	}
	if (e->icode == 0x2 || e->icode == 0x7) {
		switch (e->ifun) {
			case 0x0:
				e->Bch = true;
				break;
			case 0x1:
				e->Bch = (CC[0] || CC[1]);
				break;
			case 0x2:
				e->Bch = CC[1];
				break;
			case 0x3:
				e->Bch = CC[0];
				break;
			case 0x4:
				e->Bch = !CC[0];
				break;
			case 0x5:
				e->Bch = !CC[1];
				break;
			case 0x6:
				e->Bch = (!CC[0] && !CC[1]);
				break;
			default:
				e->status = 4;
		}
	}
}

void memory(State* m) {
	if (m == NULL) return;
	switch (m->icode) {
		case 0x4:
		case 0xa:
			L1[m->valE] = (unsigned char) m->valA & 0x000000ff;
			L1[m->valE + 1] = (unsigned char) (m->valA>>8) & 0x000000ff;
			L1[m->valE + 2] = (unsigned char) (m->valA>>16) & 0x000000ff;
			L1[m->valE + 3] = (unsigned char) (m->valA>>24) & 0x000000ff;
			break;
		case 0x5:
			m->valM = L1[m->valE] + (L1[m->valE + 1]<<8) + (L1[m->valE + 2]<<16) + (L1[m->valE + 3]<<24);
			break;
		case 0x8:
			L1[m->valE] = (unsigned char) m->valP & 0x000000ff;
			L1[m->valE + 1] = (unsigned char) (m->valP>>8) & 0x000000ff;
			L1[m->valE + 2] = (unsigned char) (m->valP>>16) & 0x000000ff;
			L1[m->valE + 3] = (unsigned char) (m->valP>>24) & 0x000000ff;
			break;
		case 0x9:
		case 0xb:
			m->valM = L1[m->valA] + (L1[m->valA + 1]<<8) + (L1[m->valA + 2]<<16) + (L1[m->valA + 3]<<24);
			break;
		case 0xe:
			if (m->ifun == 0x1)
				m->valM = m->valE;
			else if (m->ifun == 0x9)
				m->valM = L1[m->valE] + (L1[m->valE + 1]<<8) + (L1[m->valE + 2]<<16) + (L1[m->valE + 3]<<24);
			else
				m->status = 4;
			break;
	}
}

void write_back(State* w) {
	if (w == NULL) return;
	if (w->icode == 0x2 && !w->Bch) {
		w->dstE = 0xf;
	}
	registers.setRegister(w->dstE, (int)w->valE);
	registers.setRegister(w->dstM, (int)w->valM);
	
	//update pc
	if (w->Bch) {
		switch (w->icode) {
			case 0x7:
			case 0x8:
				PC = w->valC;
				break;
			case 0x9:
			case 0xe:
				PC = w->valM;
				break;
			case 0x2:
			default:
				PC = w->valP;
				break;
		}
	} else
		PC = w->valP;
}

char simulate() {
	State* S;
	while (true) {
		S = new State();
		fetch(S);
		if (S->status != 1)
			return S->status;
		decode(S);
		execute(S);
		if (S->status != 1)
			return S->status;
		memory(S);
		if (S->status != 1)
			return S->status;
		write_back(S); // pc update in here for now
		if (S->status != 1)
			return S->status;
		S->~State();
	}
}

int main(int argc, char* argv[]) {
	if (argc != 2) {
		printf("Usage: %s file\n", argv[0]);
		return -1;
	}
	FILE * code;
	code = fopen(argv[1], "rb");
	if (code == NULL) {
		printf("Invalid file.\n");
		return -1;
	}
	
	// get file size
	fseek(code, 0, SEEK_END);
	codesize = ftell(code);
	rewind(code);
	
	// read input
	L1 = (unsigned char*)malloc(codesize * sizeof(unsigned char));
	fread(L1, 1, codesize, code);
	
	// close file
	fclose(code);
	
	// set up
	PC = 0x0;
	CC[0] = true;
	CC[1] = false;
	CC[2] = false;
	
	// Simulate
	char status = simulate();
	
	// End
	printf("\nStatus: %s\n", statcode[(int)status]);
	printf("\nRegisters:\n");
	for (unsigned char i = 0; i < 8; i++) {
		int temp = registers.getRegister(i);
		printf("r%d %s: 0x%08x %d\n", i, registers.getRegName(i), temp, temp);
	}
	printf("\nCondition codes:\n");
	printf("ZF: %d; SF: %d; OF: %d\n", (int)CC[0], (int)CC[1], (int)CC[2]);
	
	printf("\nPC: %d\n", PC);
	
	free(L1);
	return 0;
}
