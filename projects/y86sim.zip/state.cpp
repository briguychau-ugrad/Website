#include "state.h"

State::State() {
	Bch = false;
	dstE = 0xf;
	dstM = 0xf;
	icode = 0;
	ifun = 0;
	newPC = 0;
	rA = 0xf;
	rB = 0xf;
	srcA = 0xf;
	srcB = 0xf;
	status = 1;
	valA = 0;
	valB = 0;
	valC = 0;
	valE = 0;
	valM = 0;
	valP = 0;
}
