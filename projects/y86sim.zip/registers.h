#ifndef REGISTERS_H
#define REGISTERS_H

class Registers {
	public:
		void setRegister(unsigned char destReg, int val);
		int getRegister(unsigned char srcReg);
		char* getRegName(unsigned char srcReg);
	private:
		int reg[8];
};

#endif
