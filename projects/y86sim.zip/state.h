#ifndef STATE_H
#define STATE_H

class State {
	public:
		State();
		bool Bch;
		unsigned char dstE;
		unsigned char dstM;
		unsigned char icode;
		unsigned char ifun;
		unsigned int newPC;
		unsigned char rA;
		unsigned char rB;
		unsigned char srcA;
		unsigned char srcB;
		unsigned char status;
		unsigned int valA;
		unsigned int valB;
		unsigned int valC;
		unsigned int valE;
		unsigned int valM;
		unsigned int valP;
};

#endif
