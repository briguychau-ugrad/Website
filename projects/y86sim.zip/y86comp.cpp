#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <math.h>

#define BUILD_VERSION "20130519-1.0.0001"

using namespace std;

typedef struct LabAd {
	unsigned int loc;
	char* name;
	LabAd* next;
} LabAd;

unsigned char* list;
unsigned int posn;
char* line;
int label_wait;
char** label;

LabAd* known;
LabAd* unknown;

void addLabelWait(char* title, int length) {
	char* temp = (char*)malloc(length * sizeof(char));
	for (int i = 0; i < length; i++) {
		temp[i] = title[i];
	}
	label[label_wait++] = temp;
}

bool findInLabels(char* title, unsigned int* addr) {
	LabAd* temp = known;
	while (temp != NULL) {
		if (temp->name == title) {
			*addr = temp->loc;
			return true;
		}
		temp = temp->next;
	}
	return false;
}

void addLabel(char* title, unsigned int address) {
	unsigned int* oldaddress = new unsigned int;
	if (findInLabels(title, oldaddress)) {
		if (*oldaddress != address)
			throw 7;
		delete oldaddress;
	} else {
		delete oldaddress;
		
		LabAd* newlabel = new LabAd;
		newlabel->loc = address;
		newlabel->name = title;
		newlabel->next = known;
		known = newlabel;
	}
}

bool stringEq(char* strA, char* strB) {
	if (strlen(strA) != strlen(strB)) return false;
	int len = strlen(strA);
	for (int i = 0; i < len; i++) {
		if (strA[i] != strB[i]) return false;
	}
	return true;
}

unsigned int findLabelAddress(char* title) {
	LabAd* temp = known;
	while (temp != NULL) {
		if (stringEq(temp->name, title)) {
			return temp->loc;
		}
		temp = temp->next;
	}
	throw 8;
}

void addReplace(char* title, unsigned int address) {
	int length = strlen(title) + 1;
	char* temp = (char*)malloc(length * sizeof(char));
	for (int i = 0; i < length; i++) {
		temp[i] = title[i];
	}
	
	LabAd* newlabel = new LabAd;
	newlabel->loc = address;
	newlabel->name = temp;
	newlabel->next = unknown;
	unknown = newlabel;
}

int findreg(string reg) {
	if (reg == "%eax") {
		return 0;
	} else if (reg == "%ecx") {
		return 1;
	} else if (reg == "%edx") {
		return 2;
	} else if (reg == "%ebx") {
		return 3;
	} else if (reg == "%esp") {
		return 4;
	} else if (reg == "%ebp") {
		return 5;
	} else if (reg == "%esi") {
		return 6;
	} else if (reg == "%edi") {
		return 7;
	}
	throw 3;
}

void processLine() {
	// split strings into tokens
	
	// these are for JMP indirect
	char* star = strchr(line, '*');
	char* hash = strchr(line, '#');	
	
	char* token;
	string str;
	string temp;
	int len;
	int x;
	
	token = strtok(line, " ,\t\n");
	
	start:
	
	if (token == NULL) return;
	if (token[0] == '#') return;
	
	str = token;
	len = strlen(token);
	
	if (str == ".pos") {
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') throw 1;
		posn = (unsigned int)strtol(token, NULL, 0);
		if (label_wait) {
			for (int i = 0; i < label_wait; i++) {
				try {
					addLabel(label[i], posn); // LABEL THING
				} catch (int ptr) {
					throw ptr;
				}
			}
			label_wait = 0;
		}
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') return;
		throw 1;
	}
	else if (str == ".align") {
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') throw 2;
		x = (unsigned int)strtol(token, NULL, 0);
		posn += (x - (posn % x)) % x;
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') return;
		throw 2;
	} else if (str == ".long") {
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') throw 6;
		if (label_wait != 0) {
			for (int i = 0; i < label_wait; i++) {
				try {
					addLabel(label[i], posn); // LABEL THING
				} catch (int ptr) {
					throw ptr;
				}
			}
			label_wait = 0;
		}
		
		x = (unsigned int)strtol(token, NULL, 0);
		
		token = strtok(NULL, " ,\t\n");
		bool extended = true;
		if (token == NULL || token[0] == '#') extended = false;
		unsigned int y = 1;
		if (extended) {
			y = (unsigned int)strtol(token, NULL, 0);
			if (y == 0) throw 6;
		}
		
		for (unsigned int i = 0; i < y; i++) {
			list[posn++] = (unsigned char)x&0x000000ff;
			list[posn++] = (unsigned char)(x>>8)&0x000000ff;
			list[posn++] = (unsigned char)(x>>16)&0x000000ff;
			list[posn++] = (unsigned char)(x>>24)&0x000000ff;
		}
		if (!extended) return;
		
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') return;
		
		throw 6;
	} else if (str.substr(len - 1, 1) == ":") {
		
		addLabelWait((char*)str.substr(0, len - 1).c_str(), len);
		
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') return;
		goto start;
	}
	
	
	if (label_wait != 0) {
		for (int i = 0; i < label_wait; i++) {
			try {
				addLabel(label[i], posn); // LABEL THING
			} catch (int ptr) {
				throw ptr;
			}
		}
		label_wait = 0;
	}
	
	int reg_need = 0;
	bool ints = false;
	bool mrmovl = false;
	bool rmmovl = false;
	bool irmovl = false;
	if (str == "halt") {
		list[posn++] = 0x00;
	} else if (str == "nop") {
		list[posn++] = 0x10;
	} else if (str == "rrmovl") {
		list[posn++] = 0x20;
		reg_need = 11;
	} else if (str == "cmovle") {
		list[posn++] = 0x21;
		reg_need = 11;
	} else if (str == "cmovl") {
		list[posn++] = 0x22;
		reg_need = 11;
	} else if (str == "cmove") {
		list[posn++] = 0x23;
		reg_need = 11;
	} else if (str == "cmovne") {
		list[posn++] = 0x24;
		reg_need = 11;
	} else if (str == "cmovge") {
		list[posn++] = 0x25;
		reg_need = 11;
	} else if (str == "cmovg") {
		list[posn++] = 0x26;
		reg_need = 11;
	} else if (str == "irmovl") {
		list[posn++] = 0x30;
		reg_need = 1;
		irmovl = true;
	} else if (str == "rmmovl") {
		list[posn++] = 0x40;
		reg_need = 11;
		rmmovl = true;
	} else if (str == "mrmovl") {
		list[posn++] = 0x50;
		reg_need = 11;
		mrmovl = true;
	} else if (str == "addl") {
		list[posn++] = 0x60;
		reg_need = 11;
	} else if (str == "subl") {
		list[posn++] = 0x61;
		reg_need = 11;
	} else if (str == "andl") {
		list[posn++] = 0x62;
		reg_need = 11;
	} else if (str == "xorl") {
		list[posn++] = 0x63;
		reg_need = 11;
	// UBC ONLY
	} else if (str == "mull") {
		list[posn++] = 0x64;
		reg_need = 11;
	} else if (str == "divl") {
		list[posn++] = 0x65;
		reg_need = 11;
	} else if (str == "modl") {
		list[posn++] = 0x66;
		reg_need = 11;
	// END UBC ONLY
	} else if (str == "jmp") {
		
		/*//REGULAR:
		list[posn++] = 0x70;
		ints = true;
		*/
		
		bool dblIndrJmp = false;
		
		if (star != NULL) {
			if (hash == NULL) {
				dblIndrJmp = true;
			} else {
				if (star < hash)
					dblIndrJmp = true;
			}
		}
		
		// get next string: the address
		char* jumpDest = strtok(NULL, " ,\t\n()*");
		if (jumpDest == NULL || jumpDest[0] == '#') throw 5;
		
		// get next string after that (registers for indirect jumps)
		token = strtok(NULL, " ,\t\n()*");
		
		//check if there is such a string
		if (token == NULL || token[0] == '#') {
			if (dblIndrJmp) {
				// ERROR
				throw 5;
			} else {
				// DIRECT JUMP
				list[posn++] = 0x70;
			}
		} else {
			// INDIRECT JUMP
			if (dblIndrJmp) {
				// DOUBLE INDIRECT
				list[posn++] = 0xe9;
			} else {
				// SINGLE INDIRECT
				list[posn++] = 0xe1;
			}
			// Registers for Indirect
			str = token;
			int r2;
			try {
				r2 = findreg(str);
			} catch (int ptr) {
				throw ptr;
			}
			list[posn++] = (unsigned char)(0x00f0+r2);
		}
		
		// parse the destination
		
		bool isLabel = false;
		
		int val = (unsigned int)strtol(jumpDest, NULL, 0);
		
		for (unsigned int i = 0; i < strlen(jumpDest); i++) {
			char c = jumpDest[i];
			if (c != '0' && c != 'x' && c != 'X') {
				isLabel = true;
				break;
			}
		}
		if (val != 0 || !isLabel) {
			list[posn++] = (unsigned char)val&0x000000ff;
			list[posn++] = (unsigned char)(val>>8)&0x000000ff;
			list[posn++] = (unsigned char)(val>>16)&0x000000ff;
			list[posn++] = (unsigned char)(val>>24)&0x000000ff;
		} else {
			addReplace(jumpDest, posn); // LABEL THING
			posn += 4;
		}
		
		token = strtok(NULL, " ,\t\n()*");
		if (token == NULL || token[0] == '#') return;
		throw 5;
		
	} else if (str == "jle") {
		list[posn++] = 0x71;
		ints = true;
	} else if (str == "jl") {
		list[posn++] = 0x72;
		ints = true;
	} else if (str == "je") {
		list[posn++] = 0x73;
		ints = true;
	} else if (str == "jne") {
		list[posn++] = 0x74;
		ints = true;
	} else if (str == "jge") {
		list[posn++] = 0x75;
		ints = true;
	} else if (str == "jg") {
		list[posn++] = 0x76;
		ints = true;
	} else if (str == "call") {
		list[posn++] = 0x80;
		ints = true;
	} else if (str == "ret") {
		list[posn++] = 0x90;
	} else if (str == "pushl") {
		list[posn++] = 0xa0;
		reg_need = 10;
	} else if (str == "popl") {
		list[posn++] = 0xb0;
		reg_need = 10;
	} else {
		throw 5;
	}
	if (irmovl) {
		token = strtok(NULL, " ,$\t\n");
		if (token == NULL) throw 4;
		if (token[0] == '#') throw 4;
		str = token;
		int val = (unsigned int)strtol(token, NULL, 0);
		bool isLabel = false;
		for (unsigned int i = 0; i < strlen(token); i++) {
			char c = token[i];
			if (c != '0' && c != 'x' && c != 'X') {
				isLabel = true;
				break;
			}
		}
		char* dest = token;
		token = strtok(NULL, " ,\t\n");
		if (token == NULL) throw 3;
		if (token[0] == '#') throw 3;
		str = token;
		int r2;
		try {
			r2 = findreg(str);
		} catch (int ptr) {
			throw ptr;
		}
		list[posn++] = (unsigned char)(0x00f0+r2);
		
		if (val != 0 || !isLabel) {
			list[posn++] = (unsigned char)val&0x000000ff;
			list[posn++] = (unsigned char)(val>>8)&0x000000ff;
			list[posn++] = (unsigned char)(val>>16)&0x000000ff;
			list[posn++] = (unsigned char)(val>>24)&0x000000ff;
		} else {
			addReplace(dest, posn); // LABEL THING
			posn += 4;
		}
	}
	if (reg_need != 0 && !mrmovl && !rmmovl && !irmovl) {
		int r1 = 0x0F;
		int r2 = 0x0F;
		if (reg_need / 10 == 1) {
			token = strtok(NULL, " ,\t\n");
			if (token == NULL) throw 3;
			if (token[0] == '#') throw 3;
			str = token;
			try {
				r1 = findreg(str);
			} catch (int ptr) {
				throw ptr;
			}
		}
		if (reg_need % 10 == 1) {
			token = strtok(NULL, " ,\t\n");
			if (token == NULL) throw 3;
			if (token[0] == '#') throw 3;
			str = token;
			try {
				r2 = findreg(str);
			} catch (int ptr) {
				throw ptr;
			}
		}
		list[posn++] = (unsigned char)((r1<<4)+r2);
	}
	if (mrmovl) {
		token = strtok(NULL, " (),\t\n");
		if (token == NULL) throw 5;
		if (token[0] == '#') throw 5;
		
		str = token;
		int val = (unsigned int)strtol(token, NULL, 0);
		bool isLabel = false;
		for (unsigned int i = 0; i < strlen(token); i++) {
			char c = token[i];
			if (c != '0' && c != 'x' && c != 'X') {
				isLabel = true;
				break;
			}
		}
		
		int r1, r2;
		
		char* dest = token;
		token = strtok(NULL, " (),\t\n");
		if (token == NULL) throw 3;
		if (token[0] == '#') throw 3;
		str = token;
		try {
			r2 = findreg(str);
		} catch (int ptr) {
			throw ptr;
		}
		token = strtok(NULL, " (),\t\n");
		if (token == NULL) throw 3;
		if (token[0] == '#') throw 3;
		str = token;
		try {
			r1 = findreg(str);
		} catch (int ptr) {
			throw ptr;
		}
		
		list[posn++] = (unsigned char)((r1<<4)+r2);
		if (val != 0 || !isLabel) {
			list[posn++] = (unsigned char)val&0x000000ff;
			list[posn++] = (unsigned char)(val>>8)&0x000000ff;
			list[posn++] = (unsigned char)(val>>16)&0x000000ff;
			list[posn++] = (unsigned char)(val>>24)&0x000000ff;
		} else {
			addReplace(dest, posn); // LABEL THING
			posn += 4;
		}
	}
	if (rmmovl) {
		int r1, r2;
		
		token = strtok(NULL, " (),\t\n");
		if (token == NULL || token[0] == '#') throw 3;
		str = token;
		try {
			r1 = findreg(str);
		} catch (int ptr) {
			throw ptr;
		}
		token = strtok(NULL, " (),\t\n");
		if (token == NULL || token[0] == '#') throw 5;
		
		str = token;
		int val = (unsigned int)strtol(token, NULL, 0);
		bool isLabel = false;
		for (unsigned int i = 0; i < strlen(token); i++) {
			char c = token[i];
			if (c != '0' && c != 'x' && c != 'X') {
				isLabel = true;
				break;
			}
		}
		
		char* dest = token;
		token = strtok(NULL, " (),\t\n");
		if (token == NULL || token[0] == '#') throw 3;
		str = token;
		try {
			r2 = findreg(str);
		} catch (int ptr) {
			throw ptr;
		}
		
		list[posn++] = (unsigned char)((r1<<4)+r2);
		if (val != 0 || !isLabel) {
			list[posn++] = (unsigned char)val&0x000000ff;
			list[posn++] = (unsigned char)(val>>8)&0x000000ff;
			list[posn++] = (unsigned char)(val>>16)&0x000000ff;
			list[posn++] = (unsigned char)(val>>24)&0x000000ff;
		} else {
			addReplace(dest, posn); // LABEL THING
			posn += 4;
		}
	}
	if (ints) {
		token = strtok(NULL, " ,\t\n");
		if (token == NULL || token[0] == '#') throw 4;
		str = token;
		int val = (unsigned int)strtol(token, NULL, 0);
		bool isLabel = false;
		for (unsigned int i = 0; i < strlen(token); i++) {
			char c = token[i];
			if (c != '0' && c != 'x' && c != 'X') {
				isLabel = true;
				break;
			}
		}
		if (val != 0 || !isLabel) {
			list[posn++] = (unsigned char)val&0x000000ff;
			list[posn++] = (unsigned char)(val>>8)&0x000000ff;
			list[posn++] = (unsigned char)(val>>16)&0x000000ff;
			list[posn++] = (unsigned char)(val>>24)&0x000000ff;
		} else {
			addReplace(token, posn); // LABEL THING
			posn += 4;
		}
	}
	
	token = strtok(NULL, " ,\t\n");
	if (token == NULL || token[0] == '#') return;
	throw 5;
}

int main(int argc, char* argv[]) {
	if (argc != 3) {
		printf("Usage: %s input output\n\n", argv[0]);
		printf("Converts Y86 assembly code into Y86 bytecode for simulator.\n");
		printf("The file limit is 8KB, so limit address to .pos 0x2000 maximum.\n");
		printf("Additionally, the line length limit is 255 characters.\n");
		return -1;
	}
	
	// read input
	FILE * infile;
	infile = fopen(argv[1], "rb");
	if (infile == NULL) {
		printf("Invalid input file.\n");
		return -1;
	}
	
	// initialize
	list = (unsigned char*)malloc(8192 * sizeof(char));
	posn = 0x0;
	label_wait = 0;
	label = (char**)malloc(20 * sizeof(char*));
	known = NULL;
	unknown = NULL;
	line = (char*)malloc(256 * sizeof(char));
	
	int count = 0;
	unsigned int maxaddress = 0;
	while (true) {
		if (fgets(line, 256, infile) == NULL)
			break;
		count++;
		try {
			processLine();
		} catch (int ptr) {
			printf("Line #%d: Error %d\n", count, ptr);
			/*
				Error 1: .pos
				Error 2: .align
				Error 3: Register
				Error 4: Constant
				Error 5: Instruction
				Error 6: .long
				Error 7: Label
			*/
			return -1;
		}
		maxaddress = max(posn, maxaddress);
	}
	
	// close file
	fclose(infile);
	
	unsigned int val;
	// 2nd pass for all labels
	LabAd* passptr = unknown;
	while (passptr != NULL) {
		posn = passptr->loc;
		try {
			val = findLabelAddress(passptr->name);
		} catch (int ptr) {
			printf("Error %d\n", ptr);
			/*
				Error 8: Can't find label
			*/
			return -1;
		}
		list[posn++] = (unsigned char)val&0x000000ff;
		list[posn++] = (unsigned char)(val>>8)&0x000000ff;
		list[posn++] = (unsigned char)(val>>16)&0x000000ff;
		list[posn++] = (unsigned char)(val>>24)&0x000000ff;
		
		maxaddress = max(posn, maxaddress);
		passptr = passptr->next;
	}
	
	// write to output
	FILE * outfile;
	outfile = fopen(argv[2], "wb");
	
	fwrite(list, 1, maxaddress, outfile);
	
	printf("Filesize: %d bytes\n", maxaddress);
	
	// close files and free memory
	free((void*)line);
	free((void*)label);
	free((void*)list);
	fclose(outfile);
	return 0;
}
