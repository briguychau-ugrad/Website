#include "registers.h"

void Registers::setRegister(unsigned char destReg, int val) {
	if (destReg >= (unsigned char) 0x8)
		return;
	reg[destReg] = val;
}

int Registers::getRegister(unsigned char srcReg) {
	if (srcReg >= (unsigned char) 0x8)
		return 0;
	return reg[srcReg];
}

char* Registers::getRegName(unsigned char srcReg) {
	switch (srcReg) {
		case 0:
			return (char*)"\%eax";
		case 1:
			return (char*)"\%ecx";
		case 2:
			return (char*)"\%edx";
		case 3:
			return (char*)"\%ebx";
		case 4:
			return (char*)"\%esp";
		case 5:
			return (char*)"\%ebp";
		case 6:
			return (char*)"\%esi";
		case 7:
			return (char*)"\%edi";
		default:
			return (char*)"error";
	}
}